# JCuratedVisitors English Patch v0.2.0 — cloud-build source

This is an experimental, separate MelonLoader patch. It does **not** edit or replace `Mods/JCuratedVisitors.dll`.

## Recommended: build with GitHub Actions

1. Create a **private** GitHub repository.
2. Upload this source archive to the repository root with the exact name `JCuratedVisitorsEnglishPatch_GitHub_Source.zip`.
3. In GitHub, choose **Add file → Create new file** and enter `.github/workflows/build.yml` as the filename.
4. Paste the workflow contents from the separately provided `build.yml`, then commit the file.
5. Open the repository's **Actions** tab and open the run named `Build JCuratedVisitors English Patch`.
6. When it finishes successfully, download the `JCuratedVisitors-English-Patch` artifact from the bottom of the run page.

GitHub's hosted runner installs the .NET 6 SDK, restores `LavaGang.MelonLoader` 0.7.3 from NuGet, and builds the patch in the cloud. No local SDK or build tools are required. Do not upload the original game DLL to GitHub.

## Install the build artifact

Extract the downloaded ZIP into the game's `Probably Stolen Demo` folder, keeping the folders in the archive:

- `Mods/JCuratedVisitorsEnglishPatch.dll`
- `UserData/JCuratedVisitorsEnglishPatch/en.json`

Keep the known-good original `Mods/JCuratedVisitors.dll` unchanged. This patch is a diagnostic prototype, not a verified complete translation. It tries to intercept common Unity UI Text and TextMeshPro text setters and logs unmatched CJK text to `UserData/JCuratedVisitorsEnglishPatch/untranslated.txt`.

If the game crashes, close it and remove only `Mods/JCuratedVisitorsEnglishPatch.dll`. The original mod DLL remains untouched.

## Local build (optional)

Requires the .NET 6 SDK; GitHub Actions is preferred if you do not want to install tools locally. Run `./build.ps1` from PowerShell in this folder.
