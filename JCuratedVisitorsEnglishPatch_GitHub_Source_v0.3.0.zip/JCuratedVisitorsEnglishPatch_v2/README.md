# JCuratedVisitors English Patch v0.3.0 — target-scoped prototype

This is an experimental separate MelonLoader patch. It does **not** edit or replace `Mods/JCuratedVisitors.dll`.

## What changed in v0.3.0

Versions 0.2.x added Harmony hooks to Unity UI text setters. In the user's mod setup, those setters are already hooked by other translation patches and the game crashed when this patch was enabled. Version 0.3.0 therefore removes all global UI setter hooks. Instead, it adds postfixes only to string-returning methods under the `CuratedVisitors` namespace in the loaded `JCuratedVisitors` assembly. It also patches the mod's own `JArcaneGui.JText`, `JFieldText`, and `JDialogueOverlay` text arguments where those helpers draw custom UI. This narrows the patch scope and is intended to reduce cross-mod interference.

This is a diagnostic step, **not a confirmed crash fix or complete translation**. Text hard-coded inside void UI methods and strings that bypass the target mod's string-return methods may remain untranslated. The patch needs in-game testing before it can be treated as stable.

## GitHub Actions build

1. In your existing private GitHub repository, replace `JCuratedVisitorsEnglishPatch_GitHub_Source.zip` in the repository root with this source archive, keeping that exact filename.
2. Commit the change. The existing workflow should run automatically.
3. Open the newest run under **Actions** and download the `JCuratedVisitors-English-Patch` artifact when it succeeds.

The workflow installs the .NET 6 SDK on GitHub's hosted runner and compiles the source. No local SDK or build tools are needed. Do not upload the original game DLL to GitHub.

## Install the test build

Extract the downloaded artifact ZIP into the `Probably Stolen Demo` game folder. It should add:

- `Mods/JCuratedVisitorsEnglishPatch.dll`
- `UserData/JCuratedVisitorsEnglishPatch/en.json`

Keep the known-good original `Mods/JCuratedVisitors.dll` unchanged. If the game crashes, close it and remove only `Mods/JCuratedVisitorsEnglishPatch.dll`.

If the game starts, check `MelonLoader/Latest.log` for `JCuratedVisitors English Patch v0.3.0` and the number of installed string-return hooks. If untranslated strings are seen, inspect `UserData/JCuratedVisitorsEnglishPatch/untranslated.txt`. Only strings returned by methods under `CuratedVisitors` plus the three targeted custom-GUI helpers are observed by this version, so the log is not expected to capture every untranslated UI string.

## Local build (optional)

Requires the .NET 6 SDK. From this folder, run `./build.ps1` in PowerShell. GitHub Actions is recommended if you do not want to install build tools locally.
