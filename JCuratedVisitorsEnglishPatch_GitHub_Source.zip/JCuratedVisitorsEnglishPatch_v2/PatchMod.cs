using System.Reflection;
using System.Text.Json;
using HarmonyLib;
using MelonLoader;

[assembly: MelonInfo(typeof(JCuratedVisitorsEnglishPatch.PatchMod), "JCuratedVisitors English Patch", "0.2.1", "Personal use")]
[assembly: MelonGame(null, null)]

namespace JCuratedVisitorsEnglishPatch;

public sealed class PatchMod : MelonMod
{
    private static readonly Dictionary<string, string> Translations = new(StringComparer.Ordinal);
    private static readonly HashSet<string> LoggedUnknown = new(StringComparer.Ordinal);
    private static readonly object LogLock = new();
    private HarmonyLib.Harmony? _harmony;
    private static readonly HashSet<MethodInfo> PatchedSetters = new();
    private static string TranslationPath = "";
    private static string UnknownPath = "";

    public override void OnInitializeMelon()
    {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string folder = Path.Combine(root, "UserData", "JCuratedVisitorsEnglishPatch");
        TranslationPath = Path.Combine(folder, "en.json");
        UnknownPath = Path.Combine(folder, "untranslated.txt");
        Directory.CreateDirectory(folder);
        LoadTranslations();
        _harmony = new HarmonyLib.Harmony("personal.jcuratedvisitors.englishpatch.v2");
        int patched = 0;
        // In MelonLoader's IL2CPP interop assemblies, TextMeshPro types use the
        // Il2CppTMPro namespace. Avoid probing the nonexistent managed TMPro names:
        // AccessTools.TypeByName scans many assemblies, producing reflection errors
        // for unrelated IL2CPP proxy types when a type name cannot be found.
        patched += TryPatchTextSetter("UnityEngine.UI.Text");
        patched += TryPatchTextSetter("Il2CppTMPro.TMP_Text");
        LoggerInstance.Msg($"Loaded {Translations.Count} external exact-string translations; installed {patched} text hook(s).");
        LoggerInstance.Msg($"Untranslated CJK UI strings, if any, will be logged to: {UnknownPath}");
        LoggerInstance.Msg("The translation dictionary is external; it is not embedded in this DLL.");
    }

    private void LoadTranslations()
    {
        try
        {
            if (!File.Exists(TranslationPath))
            {
                LoggerInstance.Error($"Translation file is missing: {TranslationPath}");
                return;
            }
            var parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(TranslationPath));
            if (parsed is not null)
            {
                foreach (var pair in parsed)
                {
                    if (!string.IsNullOrEmpty(pair.Key) && pair.Value is not null)
                        Translations[pair.Key] = pair.Value;
                }
            }
        }
        catch (Exception ex)
        {
            LoggerInstance.Error($"Could not load external translation file: {ex}");
        }
    }

    private int TryPatchTextSetter(string typeName)
    {
        try
        {
            Type? type = FindLoadedType(typeName);
            MethodInfo? setter = type is null ? null : AccessTools.Property(type, "text")?.GetSetMethod();
            if (setter is null)
            {
                LoggerInstance.Warning($"Text setter not found: {typeName}.text");
                return 0;
            }
            if (!PatchedSetters.Add(setter)) return 0;
            _harmony!.Patch(setter, prefix: new HarmonyMethod(typeof(PatchMod), nameof(TextSetterPrefix)));
            LoggerInstance.Msg($"Hooked {typeName}.text");
            return 1;
        }
        catch (Exception ex)
        {
            LoggerInstance.Warning($"Could not hook {typeName}.text: {ex.Message}");
            return 0;
        }
    }

    // Resolve by exact type name from already loaded assemblies. AccessTools.TypeByName
    // can enumerate every type in every assembly, which is noisy in this IL2CPP game:
    // many generated Unity proxy assemblies contain types that reflection cannot load.
    private static Type? FindLoadedType(string fullName)
    {
        try
        {
            Type? direct = Type.GetType(fullName, throwOnError: false, ignoreCase: false);
            if (direct is not null) return direct;
        }
        catch { /* Continue with the assemblies already loaded by MelonLoader. */ }

        foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            try
            {
                Type? found = assembly.GetType(fullName, throwOnError: false, ignoreCase: false);
                if (found is not null) return found;
            }
            catch (Exception) { /* Skip assemblies that don't support this reflection query. */ }
        }
        return null;
    }

    private static void TextSetterPrefix(ref string __0)
    {
        if (string.IsNullOrEmpty(__0)) return;
        if (Translations.TryGetValue(__0, out string? translated))
        {
            __0 = translated;
            return;
        }
        if (ContainsCjkOrEastAsianPunctuation(__0)) LogUnknown(__0);
    }

    private static bool ContainsCjkOrEastAsianPunctuation(string text)
    {
        foreach (char c in text)
        {
            if ((c >= '\u3400' && c <= '\u4DBF') ||
                (c >= '\u4E00' && c <= '\u9FFF') ||
                (c >= '\uF900' && c <= '\uFAFF') ||
                (c >= '\u3000' && c <= '\u303F') ||
                (c >= '\uFF00' && c <= '\uFFEF'))
                return true;
        }
        return false;
    }

    private static void LogUnknown(string text)
    {
        lock (LogLock)
        {
            if (!LoggedUnknown.Add(text)) return;
            try
            {
                string singleLine = text.Replace("\r", "\\r").Replace("\n", "\\n");
                File.AppendAllText(UnknownPath, singleLine + Environment.NewLine, System.Text.Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Melon<PatchMod>.Logger.Warning($"Could not write untranslated string log: {ex.Message}");
            }
        }
    }
}
