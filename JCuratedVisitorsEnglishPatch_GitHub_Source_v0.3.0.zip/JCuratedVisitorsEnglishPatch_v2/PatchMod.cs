using System.Reflection;
using System.Text.Json;
using HarmonyLib;
using MelonLoader;

[assembly: MelonInfo(typeof(JCuratedVisitorsEnglishPatch.PatchMod), "JCuratedVisitors English Patch", "0.3.0", "Personal use")]
[assembly: MelonGame(null, null)]

namespace JCuratedVisitorsEnglishPatch;

/// <summary>
/// A target-scoped translation patch for JCuratedVisitors.
/// Unlike v0.2.x, this version deliberately does NOT patch Unity UI text setters.
/// It post-processes string return values of methods declared in JCuratedVisitors.dll
/// only. That avoids adding another global Harmony hook to UI setters already used by
/// other translation mods.
/// </summary>
public sealed class PatchMod : MelonMod
{
    private static readonly Dictionary<string, string> Translations = new(StringComparer.Ordinal);
    private static readonly HashSet<string> LoggedUnknown = new(StringComparer.Ordinal);
    private static readonly object LogLock = new();
    private HarmonyLib.Harmony? _harmony;
    private static string TranslationPath = "";
    private static string UnknownPath = "";

    public override void OnInitializeMelon()
    {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string folder = Path.Combine(root, "UserData", "JCuratedVisitorsEnglishPatch");
        TranslationPath = Path.Combine(folder, "en.json");
        UnknownPath = Path.Combine(folder, "untranslated.txt");
        Directory.CreateDirectory(folder);
        LoadTranslations();

        _harmony = new HarmonyLib.Harmony("personal.jcuratedvisitors.englishpatch.v3");
        (int patched, int failed) = PatchTargetStringMethods();
        int guiPatched = PatchArcaneGuiTextArguments();
        LoggerInstance.Msg($"Loaded {Translations.Count} external exact-string translations.");
        LoggerInstance.Msg($"Installed {patched} JCuratedVisitors string-return hooks; {failed} methods could not be patched.");
        LoggerInstance.Msg($"Installed {guiPatched} targeted JArcaneGui text-argument hook(s).");
        LoggerInstance.Msg("No global UnityEngine.UI.Text or TextMeshPro setters are patched by this version.");
        LoggerInstance.Msg($"Untranslated CJK strings returned by JCuratedVisitors methods, if any, will be logged to: {UnknownPath}");
    }

    private void LoadTranslations()
    {
        try
        {
            if (!File.Exists(TranslationPath))
            {
                LoggerInstance.Error($"Translation file is missing: {TranslationPath}");
                return;
            }

            var parsed = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(TranslationPath));
            if (parsed is not null)
            {
                foreach (var pair in parsed)
                {
                    if (!string.IsNullOrEmpty(pair.Key) && pair.Value is not null)
                        Translations[pair.Key] = pair.Value;
                }
            }
        }
        catch (Exception ex)
        {
            LoggerInstance.Error($"Could not load external translation file: {ex}");
        }
    }

    private (int patched, int failed) PatchTargetStringMethods()
    {
        Assembly? target = AppDomain.CurrentDomain.GetAssemblies()
            .FirstOrDefault(a => string.Equals(a.GetName().Name, "JCuratedVisitors", StringComparison.OrdinalIgnoreCase));

        if (target is null)
        {
            LoggerInstance.Error("Could not find loaded assembly JCuratedVisitors. No methods were patched.");
            return (0, 0);
        }

        Type[] types;
        try
        {
            types = target.GetTypes();
        }
        catch (ReflectionTypeLoadException ex)
        {
            // The original mod is managed, but keep any successfully loaded types if a
            // noncritical generated type fails reflection for any reason.
            types = ex.Types.Where(t => t is not null).Cast<Type>().ToArray();
            LoggerInstance.Warning($"Some JCuratedVisitors types could not be inspected; continuing with {types.Length} available types.");
        }
        catch (Exception ex)
        {
            LoggerInstance.Error($"Could not enumerate JCuratedVisitors types: {ex}");
            return (0, 0);
        }

        int patched = 0;
        int failed = 0;
        var postfix = new HarmonyMethod(typeof(PatchMod), nameof(StringResultPostfix));
        var seen = new HashSet<MethodInfo>();

        foreach (Type type in types)
        {
            if (!BelongsToCuratedVisitors(type))
                continue;

            MethodInfo[] methods;
            try
            {
                methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic |
                                          BindingFlags.Static | BindingFlags.Instance |
                                          BindingFlags.DeclaredOnly);
            }
            catch
            {
                continue;
            }

            foreach (MethodInfo method in methods)
            {
                try
                {
                    if (method.ReturnType != typeof(string) || method.IsAbstract || method.ContainsGenericParameters)
                        continue;
                    if (method.GetMethodBody() is null || !seen.Add(method))
                        continue;

                    _harmony!.Patch(method, postfix: postfix);
                    patched++;
                }
                catch (Exception ex)
                {
                    failed++;
                    // Keep diagnostics bounded; a single unusual method should not stop
                    // the rest of the target-scoped methods from being patched.
                    if (failed <= 8)
                        LoggerInstance.Warning($"Could not patch {type.FullName}.{method.Name}: {ex.Message}");
                }
            }
        }

        return (patched, failed);
    }


    private static bool BelongsToCuratedVisitors(Type type)
    {
        // Include nested compiler-generated types belonging to this namespace, while
        // excluding unrelated helper namespaces bundled in the same assembly.
        for (Type? current = type; current is not null; current = current.DeclaringType)
        {
            if (string.Equals(current.Namespace, "CuratedVisitors", StringComparison.Ordinal))
                return true;
        }
        return false;
    }

    private int PatchArcaneGuiTextArguments()
    {
        Assembly? target = AppDomain.CurrentDomain.GetAssemblies()
            .FirstOrDefault(a => string.Equals(a.GetName().Name, "JCuratedVisitors", StringComparison.OrdinalIgnoreCase));
        Type? gui = target?.GetType("CuratedVisitors.JArcaneGui", throwOnError: false, ignoreCase: false);
        if (gui is null)
        {
            LoggerInstance.Warning("Could not find CuratedVisitors.JArcaneGui; custom adventure overlay arguments were not patched.");
            return 0;
        }

        int count = 0;
        const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly;
        foreach (MethodInfo method in gui.GetMethods(flags))
        {
            try
            {
                ParameterInfo[] p = method.GetParameters();
                HarmonyMethod? prefix = null;
                if (method.Name == "JText" && method.ReturnType == typeof(void) && p.Length == 5 && p[3].ParameterType == typeof(string))
                    prefix = new HarmonyMethod(typeof(PatchMod), nameof(JTextPrefix));
                else if (method.Name == "JFieldText" && method.ReturnType == typeof(void) && p.Length == 5 && p[1].ParameterType == typeof(string))
                    prefix = new HarmonyMethod(typeof(PatchMod), nameof(JFieldTextPrefix));
                else if (method.Name == "JDialogueOverlay" && method.ReturnType == typeof(int) && p.Length == 4 &&
                         p[0].ParameterType == typeof(string) && p[1].ParameterType == typeof(string) &&
                         p[2].ParameterType == typeof(string) && p[3].ParameterType == typeof(string[]))
                    prefix = new HarmonyMethod(typeof(PatchMod), nameof(JDialogueOverlayPrefix));

                if (prefix is null)
                    continue;
                _harmony!.Patch(method, prefix: prefix);
                count++;
            }
            catch (Exception ex)
            {
                LoggerInstance.Warning($"Could not patch targeted GUI method {method.Name}: {ex.Message}");
            }
        }
        return count;
    }

    private static void JTextPrefix(ref string __3) => TranslateArgument(ref __3);
    private static void JFieldTextPrefix(ref string __1) => TranslateArgument(ref __1);

    private static void JDialogueOverlayPrefix(ref string __0, ref string __1, ref string __2, string[] __3)
    {
        TranslateArgument(ref __0);
        TranslateArgument(ref __1);
        TranslateArgument(ref __2);
        if (__3 is null) return;
        for (int i = 0; i < __3.Length; i++)
        {
            string value = __3[i];
            if (!string.IsNullOrEmpty(value) && Translations.TryGetValue(value, out string? translated))
                __3[i] = translated;
            else if (!string.IsNullOrEmpty(value) && value.Length <= 1000 && ContainsCjkOrEastAsianPunctuation(value))
                LogUnknown(value);
        }
    }

    private static void TranslateArgument(ref string value)
    {
        if (string.IsNullOrEmpty(value)) return;
        if (Translations.TryGetValue(value, out string? translated))
        {
            value = translated;
            return;
        }
        if (value.Length <= 1000 && ContainsCjkOrEastAsianPunctuation(value))
            LogUnknown(value);
    }

    // This postfix runs only on string-returning methods declared by JCuratedVisitors.dll.
    // It does not intercept global Unity UI setters and won't rewrite other mods' UI text.
    private static void StringResultPostfix(ref string __result)
    {
        if (string.IsNullOrEmpty(__result)) return;

        if (Translations.TryGetValue(__result, out string? translated))
        {
            __result = translated;
            return;
        }

        // Avoid writing giant serialized/save-data strings to the diagnostic log.
        if (__result.Length <= 1000 && ContainsCjkOrEastAsianPunctuation(__result))
            LogUnknown(__result);
    }

    private static bool ContainsCjkOrEastAsianPunctuation(string text)
    {
        foreach (char c in text)
        {
            if ((c >= '\u3400' && c <= '\u4DBF') ||
                (c >= '\u4E00' && c <= '\u9FFF') ||
                (c >= '\uF900' && c <= '\uFAFF') ||
                (c >= '\u3000' && c <= '\u303F') ||
                (c >= '\uFF00' && c <= '\uFFEF'))
                return true;
        }
        return false;
    }

    private static void LogUnknown(string text)
    {
        lock (LogLock)
        {
            if (!LoggedUnknown.Add(text)) return;
            try
            {
                string singleLine = text.Replace("\r", "\\r").Replace("\n", "\\n");
                File.AppendAllText(UnknownPath, singleLine + Environment.NewLine, System.Text.Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Melon<PatchMod>.Logger.Warning($"Could not write untranslated string log: {ex.Message}");
            }
        }
    }
}
