$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'JCuratedVisitorsEnglishPatch.csproj'
$dist = Join-Path $PSScriptRoot 'dist'
$null = New-Item -ItemType Directory -Force -Path $dist

dotnet build $project -c Release -o $dist
if ($LASTEXITCODE -ne 0) { throw "dotnet build failed with exit code $LASTEXITCODE" }

Write-Host ''
Write-Host 'Build completed. This script did not modify the original mod or install the patch.'
Write-Host "Patch DLL: $(Join-Path $dist 'JCuratedVisitorsEnglishPatch.dll')"
Write-Host "Translation JSON: $(Join-Path $PSScriptRoot 'Translations\en.json')"
